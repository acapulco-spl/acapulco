/**
 */
package org.eclipse.emf.henshin.model;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>True</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.emf.henshin.model.HenshinPackage#getTrue()
 * @model
 * @generated
 */
public interface True extends Formula {
} // True
